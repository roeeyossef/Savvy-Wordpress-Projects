<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wp_git_composer');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'root');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'FG2<it-TA=)VqQ)%1-L@bPEdjUM`u-gBo9-B*<_LkF;lhs8%hv[Ei5G?Y0;Duz?k');
define('SECURE_AUTH_KEY',  'NvH_XoF3;wM&) +}?WA/`3*I^8+b6?hj-%c9S,d4RKysTH-{cZiPo!Xv*lf6Ybp-');
define('LOGGED_IN_KEY',    ' DAZGF.<18y14g;X vd&a>T;=O}}Ej*i5)jnUBEyp.%=n%Q4lph7,6/P:j[&.eRF');
define('NONCE_KEY',        '6/cLb,N1M(-BL}ncPKyo,Xwak|gg5Yt=x#Ar]Sd|Ne }=X@7x#-:#1czM?W:|.z}');
define('AUTH_SALT',        '(k:)*a5HlG=NJZAqaZxN`8mFSXw+-Ov9|s2-EU3w+$(W|RbGv6V iCg:J,h[J^M$');
define('SECURE_AUTH_SALT', 'a,FaGR]}&sz7[e,+lOBL.aR&a)2^W}kyBf tYOC$F95JgWo5Y9DQc*g,EZmfGCrJ');
define('LOGGED_IN_SALT',   '|-WA?M_KF)Gosj~@G21,S;^^*T};(7Sln+3AQ[T]EBIR>pI]7+=y,ia-|<^Sa h.');
define('NONCE_SALT',       'cs-Bq)pi5{SgrI/p6w>Q..3Fqfb-,_Gt7@-+%qcVz2;Q(A5uc;XxLr3|r-L 6x(j');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
